#ifndef __CRC16_H__
#define __CRC16_H__
#include "main.h"

uint16_t GetCRC16(uint8_t *ptr, uint16_t length);   


#endif
