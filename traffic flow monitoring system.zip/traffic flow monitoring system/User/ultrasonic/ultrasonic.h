#ifndef _ULTRASONIC_H
#define _ULTRASONIC_H

#include "main.h"

#define Ultrasonic1_Addr   0x01   //�豸��ַ
#define Ultrasonic2_Addr   0x02
#define Small_Car          500   //С���߶�(mm)
#define Big_Car            1000  //�󳵸߶�(mm)
#define restrict_speed     40    //����40km/h

extern uint8_t  tx_ultrasonic1_Buffer[8];
extern uint8_t  tx_ultrasonic2_Buffer[8];
extern uint8_t  tx_ultrasonic1_temperature_Buffer[8];
extern uint8_t  rx_ultrasonic_Buffer[7];  
extern uint8_t  rx_ultrasonic_temp_Buffer[7];  
extern uint8_t  rx_ultrasonic_complete;

extern uint16_t Max_Height;
extern uint16_t measure_height;                          
extern double   measure_temperature;  
extern double   car_speed; 
extern double   car_avg_speed;
extern uint8_t  direction;
extern uint16_t car_num;
extern uint16_t small_car_num;
extern uint16_t big_car_num;
extern uint16_t small_car_num_sum;
extern uint16_t big_car_num_sum;      
extern uint8_t  overspeed_num;
extern uint8_t  wrong_direction_num; 
extern uint8_t  alarm_event_flag;
extern uint16_t rate_limiting;
extern uint16_t distance_ultrasonic; 

void height_initial_handle(uint8_t *buf, uint16_t len);
void height_handle(uint8_t *buf, uint16_t len);
void temperature_handle(uint8_t *buf, uint16_t len);
void handle_car_count(uint16_t, uint16_t);
void handle_car_speed(void);
void handle_car_avg_speed(void);

#endif

