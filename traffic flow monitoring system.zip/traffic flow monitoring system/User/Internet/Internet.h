#ifndef __INTERNET_H__
#define __INTERNET_H__ 
                           

#include "main.h"
#include <stdlib.h>

void internet_handle(void);
extern uint8_t Internet_time;
extern uint8_t Internet_complete;
#endif
