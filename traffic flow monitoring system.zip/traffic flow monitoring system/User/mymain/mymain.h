#ifndef __MYMAIN_H__
#define __MYMAIN_H__ 

void mymain(void);

#endif
