from datetime import datetime, timedelta  
  
# 定义起始和结束日期  
start_date = datetime(2024, 5, 15)  
end_date = datetime(2024, 5, 17)  
  
# 定义一个函数来生成经纬度的小幅变化  
def generate_location(lat, lon, variation=0.00001):  
    lat += variation * (0.5 - random.random())  # 在很小范围内随机变化  
    lon += variation * (0.5 - random.random())  
    return round(lat, 6), round(lon, 6)  # 四舍五入到六位小数  
  
# 导入random模块以生成随机数据（如果尚未导入）  
import random  
  
# 循环遍历日期并生成数据  
for current_date in (start_date + timedelta(days=x) for x in range(0, (end_date - start_date).days + 1)):  
    for hour in range(24):  
        # 假设的随机数据生成（可以根据需要调整）  
        entry_count = random.randint(5, 25)  
        exit_count = random.randint(10, 30)  
        other_field1 =  entry_count + exit_count # 假设的其他字段  
        other_field2 = random.randint(20, 50)  # 假设的其他字段  
  
        # 生成经纬度  
        lat, lon = generate_location(31.326944, 121.402072)  
  
        # 构建UNIX时间戳（从1970年1月1日开始的秒数）  
        ID = 1528564112
  
        # 构建INSERT INTO语句  
        insert_statement = f"INSERT INTO `HourlyTrafficSummary` VALUES ({ID}, '{current_date.strftime('%Y-%m-%d')}', {hour}, {entry_count}, {exit_count}, {other_field1}, {lat}, {lon});"  
        print(insert_statement)
  
# 注意：上面的脚本将打印INSERT INTO语句到控制台。  
# 如果需要将它们保存到文件中，可以使用文件I/O操作（如写入到.sql文件）。