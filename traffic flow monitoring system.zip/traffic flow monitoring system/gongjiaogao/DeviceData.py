import datetime  
import random  
  
# 起始和结束时间  
start_time = datetime.datetime(2024, 5, 10, 14, 45, 0)  
end_time = datetime.datetime(2024, 5, 10, 15, 0, 0)  
  
# 固定的设备号和其他值  
devID = 1528564112 
restrict_data = 4000  
wrong_direction_num = 0  
rate_limiting = '40'  
latitude = 31.318860  
longitude = 121.395323  
# speed = 0  # 假设速度始终为0  
  
# 生成插入语句的函数  
def generate_insert_statement(timestamp_unix, flowS, flowL, heat, overspeed_num):  
    timestamp_str = datetime.datetime.fromtimestamp(timestamp_unix).strftime('%Y-%m-%d %H:%M:%S')  
    # 注意这里使用了{:.1f}来格式化heat到一位小数  
    return f"INSERT INTO `DeviceData` VALUES ({devID}, {flowS}, {flowL}, {heat:.1f}, {latitude}, {longitude}, {speed}, {timestamp_unix}, '{timestamp_str}', {restrict_data}, {overspeed_num}, {wrong_direction_num}, '{rate_limiting}');"
# 生成插入语句的列表    
insert_statements = []    
current_time = start_time    
while current_time <= end_time:    
    flowS = random.randint(0, 4)  # 大车数量    
    flowL = random.randint(0, 4)  # 小车数量    
    heat = random.uniform(20, 30)  # 温度    
    # 使用random.random()来生成超速次数的概率  
    overspeed_num = 1 if random.random() < 0.1 else 0  # 超速次数，10%概率为1，90%概率为0  
    speed = random.randint(10, 40)  
    timestamp_unix = int(current_time.timestamp())  # 将datetime对象转换为时间戳（秒）    
        
    # 生成插入语句并添加到列表中    
    insert_statements.append(generate_insert_statement(timestamp_unix, flowS, flowL, heat, overspeed_num))    
        
    # 更新当前时间，增加10秒    
    current_time += datetime.timedelta(seconds=10)    
    
# 打印或处理生成的插入语句    
for statement in insert_statements:    
    print(statement)