/*
 Navicat Premium Data Transfer

 Source Server         : 1234
 Source Server Type    : MySQL
 Source Server Version : 50740
 Source Host           : 154.12.55.218:3306
 Source Schema         : devicedata

 Target Server Type    : MySQL
 Target Server Version : 50740
 File Encoding         : 65001

 Date: 10/05/2024 01:20:53
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for DeviceOverallSummary
-- ----------------------------
DROP TABLE IF EXISTS `DeviceOverallSummary`;
CREATE TABLE `DeviceOverallSummary`  (
  `devID` bigint(20) UNSIGNED NOT NULL,
  `totalFlow` int(10) UNSIGNED NOT NULL,
  `smallVehicleFlow` int(10) UNSIGNED NOT NULL,
  `largeVehicleFlow` int(10) UNSIGNED NOT NULL,
  `latestLatitude` decimal(14, 6) NULL DEFAULT NULL,
  `latestLongitude` decimal(14, 6) NULL DEFAULT NULL,
  `latestHeat` float NULL DEFAULT NULL,
  `avgSpeed` int(10) UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`devID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of DeviceOverallSummary
-- ----------------------------
INSERT INTO `DeviceOverallSummary` VALUES (1528564110, 8319, 4290, 4029, 31.326944, 121.402072, 23, 33);
INSERT INTO `DeviceOverallSummary` VALUES (1528564111, 6131, 3285, 2846, 31.327276, 121.406356, 26.5, 24);
INSERT INTO `DeviceOverallSummary` VALUES (1528564112, 9398, 4870, 4528, 31.325109, 121.403949, 25, 33);

SET FOREIGN_KEY_CHECKS = 1;
